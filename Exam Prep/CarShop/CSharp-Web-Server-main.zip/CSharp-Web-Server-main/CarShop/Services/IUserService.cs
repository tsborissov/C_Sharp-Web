﻿namespace CarShop.Services
{
    public interface IUserService
    {
        bool IsMechanic(string userId);
    }
}
