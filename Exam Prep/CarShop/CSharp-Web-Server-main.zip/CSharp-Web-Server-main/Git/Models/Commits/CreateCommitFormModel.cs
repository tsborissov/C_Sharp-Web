﻿namespace Git.Models.Commits
{
    public class CreateCommitFormModel
    {
        public string Id { get; init; }

        public string Description { get; init; }
    }
}
