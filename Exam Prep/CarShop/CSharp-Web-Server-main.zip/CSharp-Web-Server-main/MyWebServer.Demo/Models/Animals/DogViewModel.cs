﻿namespace MyWebServer.Demo.Models.Animals
{
    public class DogViewModel
    {
        public string Name { get; init; }

        public int Age { get; init; }

        public string Breed { get; init; }
    }
}
